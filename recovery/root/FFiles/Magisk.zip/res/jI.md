# alpha更新日志

- 如果需要使用 heapprofd（Android Heap Profiler），请关闭zygisk并重启。
- `magisk`和`su`等二进制文件不再硬编码于`/system/bin/`目录下，而是从`PATH`环境变量中选择第一个可用位置。

## Magisk (b1dc47a0-alpha)
- [App] 还原boot镜像后删除备份文件
- [App] 不主动请求权限
- [General] 移除addon.d支持
- [MagiskSU] 支持移除权能
- [General] 支持用户限制Root权能
- [App] 更新DoH
- [Zygisk] 修改 libzygisk.so 名字为 heapprofd_client.so
- [SU] 传递所有未知选项到远程shell

# 上游更新日志

## 2025.5.14 Magisk v29.0

This release looks minor at the surface, however, the entire codebase has gone through significant refactoring and migration. The native code in Magisk used to be mainly C++, but several contributors and I have been steadily rewriting parts of the code in Rust since April 2022. After years of effort, the Rust-ification of the project slowly began picking up steam, and at the moment of this release, over 40% of the native code has been rewritten in Rust, with several major subsystem rewrites in the PR queue, planned to be merged for the next release.

Many might wonder, why introduce a new language to the project? My reason is actually not to reduce memory safety issues (although it is a nice side benefit), but to be able to develop Magisk using a more modern programming language. After using Rust for a while, it's clear to me that using Rust allows me to write more correct code and makes me happier compared to dealing with C++. People share the [same sentiment as I do](https://threadreaderapp.com/thread/1577667445719912450.html).

## Changelog

- [General] Massive internal refactoring and code migration
- [App] Support downloading module zip files with XZ compression
- [App] Disable app animations when system animations are disabled
- [MagiskMount] Support systemlessly deleting files with modules using blank file nodes
- [MagiskInit] Redesign sepolicy patching and injection logic
- [MagiskSU] Better TTY/PTY support

### Full Changelog: [here](https://topjohnwu.github.io/Magisk/changes.html)
